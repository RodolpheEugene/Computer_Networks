import os
import socket

# code to handle connection
IP = "localhost"
PORT = 4450
ADDR = (IP, PORT)
SIZE = 1024
FORMAT = "utf-8"
SERVER_PATH = "/home/smiley/PROJECTS/NETWORK PROGRAMMING/FIles"

# Function for handling client
def handle_client(conn, addr):
    print(f"NEW CONNECTION: {addr} connected.")
    conn.send("OK@Welcome to the server".encode(FORMAT))

    while True:
        data = conn.recv(SIZE).decode(FORMAT)
        data = data.split("@")
        cmd = data[0]

        send_data = ""

        # for loging out of the cient
        if cmd == "LOGOUT":
            break
        
        # code for handling UPLOAD command for uploading file into folder in server
        if cmd == "UPLOAD":
            filename = data[1]
            file_data = conn.recv(SIZE)
            with open(os.path.join(SERVER_PATH, filename), "wb") as file:
                file.write(file_data)
            print(f"Received file: {filename}")
        conn.send(f"File '{filename}' uploaded successfully.\n".encode(FORMAT))
                        
        # code for handling DELETE command and remove file from server
        if cmd == "DELETE":
            filename = data[1]
            file_path = os.path.join(SERVER_PATH, filename)
            if os.path.exists(file_path):
                os.remove(file_path)
        conn.send(f"File '{filename}' deleted.\n".encode(FORMAT))

    print(f"{addr} disconnected") 
    conn.close() # closes the connection between client and server

def main():
    print("Starting the server")
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(ADDR)
    server.listen()
    print(f"Server is listening on {IP}:{PORT}")

    os.makedirs(SERVER_PATH, exist_ok=True) # create a folder if does not exist already

    while True:
        conn, addr = server.accept()
        handle_client(conn, addr)

if __name__ == "__main__":
    main()
