import os
import socket

# to connect to server
IP = "localhost"
PORT = 4450
ADDR = (IP, PORT)
SIZE = 1024
FORMAT = "utf-8"

# function for handling sending files to the server
def send_file(conn, filename):
    if os.path.exists(filename):
        conn.send(f"UPLOAD@{filename}".encode(FORMAT))
        with open(filename, "rb") as file:
            while True:
                file_data = file.read(SIZE)
                if not file_data:
                    break
                conn.send(file_data)
        conn.send(b"")  # End of file indicator
        return True
    else:
        return False

def main():
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect(ADDR)
    
    while True:
        data = client.recv(SIZE).decode(FORMAT)
        if "@" in data:
            cmd, msg = data.split("@")
            if cmd == "OK":
                print(f"{msg}")
        elif cmd == "DISCONNECTED":
            print(f"{msg}")
            break

        # getting input
        while True:
            data = input("> ")
            data = data.split(" ")
            cmd = data[0]

            # to log out of client 
            if cmd == "LOGOUT": 
                client.send(cmd.encode(FORMAT))
                break
            
            # for uploading file
            elif cmd == "UPLOAD":
                if len(data) != 2:
                    print("Usage: upload <filename>")
                else:
                    filename = data[1]
                    if send_file(client, filename):
                        print(f"File '{filename}' sent.")
                    else:
                        print(f"File '{filename}' not found.")

            # for deleting files          
            elif cmd == "DELETE":
                if len(data) != 2:
                    print("Usage: delete <filename>")
                else:
                    filename = data[1]
                    client.send(f"DELETE@{filename}".encode(FORMAT))
                    response = client.recv(SIZE).decode(FORMAT)
                    print(response)

    print("Disconnected from the server.")
    client.close() # closes connection

if __name__ == "__main__":
    main()
